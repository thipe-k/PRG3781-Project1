package ApplicationLayer.Utility;

public enum DefaultFood{
   WEDDINGFOOD,
   BIRTHDAYFOOD,
   YEARENDFUNCTIONFOOD,
   BABTISMFOOD,
   OTHERFOOD;
   //OTHER
   //Add another event called OTHER for any other event not part of the defaults
   // blah
   // ...
   
   public static DefaultFood getById(int id)
   {
      switch (id) {
         case 1:
            return DefaultFood.WEDDINGFOOD;
         case 2:
            return DefaultFood.BIRTHDAYFOOD;  
         case 3:
            return DefaultFood.YEARENDFUNCTIONFOOD;   
         case 4:
            return DefaultFood.BABTISMFOOD;   
        case 5:
             return DefaultFood.OTHERFOOD;                              
         default:
            return null;
      }
   }  
}
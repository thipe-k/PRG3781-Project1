package ApplicationLayer;

import java.io.Serializable;

public class Decoration implements Serializable
{
   /**
    *
    */
   private static final long serialVersionUID = 5L;
   private Theme theme;
   //private boolean balloons;
   //private boolean candels;
   //private int nrOfTables;
   
}

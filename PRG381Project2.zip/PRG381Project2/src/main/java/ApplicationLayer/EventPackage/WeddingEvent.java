package ApplicationLayer.EventPackage;

public class WeddingEvent extends Event   {

   /**
    *
    */
   private static final long serialVersionUID = 15L;

   @Override
   public String getType() {
      
      return "Wedding Event";
   }
   
}

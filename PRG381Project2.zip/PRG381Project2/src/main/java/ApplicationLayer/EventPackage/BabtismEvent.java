package ApplicationLayer.EventPackage;
public class BabtismEvent extends Event  {

   /**
    *
    */
   private static final long serialVersionUID = 10L;

   @Override
   public String getType() {
      return "Babtism Event";
   }
  
}

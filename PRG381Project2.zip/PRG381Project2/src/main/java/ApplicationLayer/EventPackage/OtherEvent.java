package ApplicationLayer.EventPackage;

public class OtherEvent extends Event {
    
   /**
    *
    */
   private static final long serialVersionUID = 16L;

   @Override
   public String getType() {
      return "Other Event";
   }
}

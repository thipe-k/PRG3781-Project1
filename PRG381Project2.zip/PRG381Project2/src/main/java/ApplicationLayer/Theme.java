package ApplicationLayer;
public class Theme 
{
   private String color1;
   private String color2;
   private String eventTheme;
   //the themes can also include actual theses, like a pirate theme or hawaii theme
}

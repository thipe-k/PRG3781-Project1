package ApplicationLayer;

import java.util.Vector;
import DataAccessLayer.FileHandler;

public class Operations {
   public String bookEvent(Booking booking)
   {
      FileHandler fileHandler = new FileHandler();
      String bookingnumber = booking.getBookingNum();
      fileHandler.serializeToFile(booking, bookingnumber);
      
      return   bookingnumber;
   }
   public Vector<Booking> getBookings()
   {
      FileHandler fileHandler = new FileHandler();
      Vector<Booking> data = new Vector<Booking>();
      for (Object booking : fileHandler.getSerializedData()) {
         data.add((Booking)booking);
      }
      return data;
   }
   public Booking getBooking (String bookingNumber)
   {
      Booking booking = null;
      FileHandler fileHandler = new FileHandler();
      for (Object tempBooking : fileHandler.getSerializedData()) {
             Booking temp = (Booking)tempBooking;
             if(temp.getBookingNum().equalsIgnoreCase(bookingNumber))
             {
                booking = temp;
                break;
             }
      }
      return booking;
   }
}
